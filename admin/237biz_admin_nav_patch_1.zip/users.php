<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$errors = [];

// ── HANDLE ACTIONS ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $userId = (int)($_POST['user_id'] ?? 0);

    // Reset password
    if ($action === 'reset_password' && $userId) {
        $newPass = trim($_POST['new_password'] ?? '');
        if (strlen($newPass) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT, ['cost' => 10]);
            db()->prepare("UPDATE users SET password=?, login_attempts=0, locked_until=NULL WHERE id=?")
                 ->execute([$hash, $userId]);

            // Notify user
            $st = db()->prepare("SELECT email, name FROM users WHERE id=?");
            $st->execute([$userId]);
            $u = $st->fetch();
            if ($u) {
                sendMail($u['email'],
                    t('Your 237Biz password has been reset','Votre mot de passe 237Biz a été réinitialisé'),
                    '<h2 style="color:#fff;font-family:Georgia,serif;">🔑 '.t('Password Reset','Réinitialisation du mot de passe').'</h2>
                     <p style="color:rgba(255,255,255,0.7);">'.t('Hi','Bonjour').' '.e($u['name']).',</p>
                     <p style="color:rgba(255,255,255,0.7);">'.t('An administrator has reset your password. Your new password is:','Un administrateur a réinitialisé votre mot de passe. Votre nouveau mot de passe est :').'</p>
                     <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:1rem;margin:1rem 0;font-size:1.2rem;font-family:monospace;color:#F5C842;text-align:center;">'.e($newPass).'</div>
                     <p style="color:rgba(255,255,255,0.7);">'.t('Please log in and change your password immediately.','Veuillez vous connecter et changer votre mot de passe immédiatement.').'</p>
                     <a href="'.SITE_URL.'/login" style="display:inline-block;margin:1rem 0;background:#00A878;color:#fff;padding:0.75rem 1.5rem;border-radius:5px;text-decoration:none;">'.t('Sign In →','Se connecter →').'</a>'
                );
            }
            flash('success', 'Password reset and user notified by email.');
        }
    }

    // Toggle verified
    elseif ($action === 'toggle_verified' && $userId) {
        db()->prepare("UPDATE users SET verified = !verified WHERE id=?")->execute([$userId]);
        flash('success', 'User verification status updated.');
    }

    // Toggle role (user ↔ admin)
    elseif ($action === 'toggle_role' && $userId) {
        $st = db()->prepare("SELECT role FROM users WHERE id=?");
        $st->execute([$userId]);
        $u = $st->fetch();
        $newRole = $u['role'] === 'admin' ? 'user' : 'admin';
        db()->prepare("UPDATE users SET role=? WHERE id=?")->execute([$newRole, $userId]);
        flash('success', 'User role updated to ' . $newRole . '.');
    }

    // Unlock account
    elseif ($action === 'unlock' && $userId) {
        db()->prepare("UPDATE users SET login_attempts=0, locked_until=NULL WHERE id=?")->execute([$userId]);
        flash('success', 'Account unlocked.');
    }

    // Delete user
    elseif ($action === 'delete' && $userId) {
        db()->prepare("DELETE FROM users WHERE id=? AND role != 'admin'")->execute([$userId]);
        flash('success', 'User deleted.');
    }

    // ── ASSIGN LISTING TO USER ───────────────────────────
    elseif ($action === 'assign_listing') {
        $listingId = (int)($_POST['listing_id'] ?? 0);
        if ($userId && $listingId) {
            db()->prepare("UPDATE listings SET user_id=? WHERE id=?")->execute([$userId, $listingId]);
            flash('success', 'Listing assigned to user.');
        }
    }

    // ── CREATE USER ───────────────────────────────────────
    elseif ($action === 'create_user') {
        $name        = trim($_POST['name'] ?? '');
        $email       = strtolower(trim($_POST['email'] ?? ''));
        $phone       = trim($_POST['phone'] ?? '');
        $role        = in_array($_POST['role'] ?? '', ['user','admin']) ? $_POST['role'] : 'user';
        $sendWelcome = !empty($_POST['send_welcome']);
        $customPass  = trim($_POST['custom_password'] ?? '');

        // Use custom password if provided, otherwise generate one
        $tempPass = $customPass ?: ucfirst(substr(str_shuffle('abcdefghjkmnpqrstuvwxyz'), 0, 5)) . rand(100,999) . '!';

        if (!$name)  $errors[] = 'Name is required.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required.';
        if ($customPass && strlen($customPass) < 8) $errors[] = 'Password must be at least 8 characters.';

        if (!$errors) {
            $chk = db()->prepare("SELECT id FROM users WHERE email=?");
            $chk->execute([$email]);
            if ($chk->fetch()) {
                $errors[] = 'Email already registered.';
            } else {
                $hash = password_hash($tempPass, PASSWORD_BCRYPT, ['cost' => 10]);
                db()->prepare("INSERT INTO users (name,email,password,phone,role,verified) VALUES (?,?,?,?,?,1)")
                     ->execute([$name, $email, $hash, $phone ?: null, $role]);

                // Assign listing if selected
                $assignListingId = (int)($_POST['assign_listing_id'] ?? 0);
                if ($assignListingId) {
                    $newUserId = db()->lastInsertId();
                    db()->prepare("UPDATE listings SET user_id=? WHERE id=?")
                         ->execute([$newUserId, $assignListingId]);
                }

                if ($sendWelcome) {
                    sendMail($email,
                        'Welcome to 237Biz — Your account details',
                        '<h2 style="color:#fff;font-family:Georgia,serif;">Welcome to 237Biz!</h2>
                         <p style="color:rgba(255,255,255,0.7);">Hi ' . e($name) . ',</p>
                         <p style="color:rgba(255,255,255,0.7);">Your account has been created. Here are your login details:</p>
                         <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:1.25rem;margin:1rem 0;">
                           <div style="color:rgba(255,255,255,0.5);font-size:0.82rem;margin-bottom:0.35rem;">Email</div>
                           <div style="color:#fff;font-family:monospace;margin-bottom:0.75rem;">' . e($email) . '</div>
                           <div style="color:rgba(255,255,255,0.5);font-size:0.82rem;margin-bottom:0.35rem;">Password</div>
                           <div style="color:#F5C842;font-family:monospace;font-size:1.1rem;">' . e($tempPass) . '</div>
                         </div>
                         <p style="color:rgba(255,255,255,0.5);font-size:0.82rem;">Please change your password after logging in.</p>
                         <a href="' . SITE_URL . '/login" style="display:inline-block;margin:1rem 0;background:#00A878;color:#fff;padding:0.85rem 2rem;border-radius:5px;text-decoration:none;font-weight:500;">Sign In to 237Biz</a>'
                    );
                    flash('success', 'User ' . $name . ' created and welcome email sent.');
                } else {
                    flash('success', 'User ' . $name . ' created. Temp password: ' . $tempPass);
                }
            }
        }
        if ($errors) flash('error', implode(' ', $errors));
    }

    redirect(SITE_URL . '/admin/users.php');
}

// ── FETCH USERS ───────────────────────────────────────────
$search = trim($_GET['q'] ?? '');
$where  = $search ? "WHERE name LIKE ? OR email LIKE ?" : "";
$params = $search ? ["%$search%", "%$search%"] : [];

$st = db()->prepare("
    SELECT u.*,
           (SELECT COUNT(*) FROM listings WHERE user_id=u.id) AS listing_count,
           IFNULL((SELECT COUNT(*) FROM service_orders WHERE user_id=u.id), 0) AS order_count
    FROM users u $where
    ORDER BY u.created_at DESC
    LIMIT 100
");
$st->execute($params);
$users = $st->fetchAll();

try {
    $totalUsers  = db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalAdmins = db()->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
    $unverified  = db()->query("SELECT COUNT(*) FROM users WHERE verified=0")->fetchColumn();
    $locked      = db()->query("SELECT COUNT(*) FROM users WHERE locked_until IS NOT NULL AND locked_until > NOW()")->fetchColumn();
} catch (Exception $e) {
    $totalUsers = $totalAdmins = $unverified = $locked = 0;
}

// Fetch unowned approved listings for assignment dropdown
$unownedListings = db()->query("
    SELECT l.id, l.title, loc.name_en AS loc_en
    FROM listings l
    JOIN locations loc ON loc.id = l.location_id
    WHERE l.status = 'approved'
    ORDER BY l.user_id IS NOT NULL ASC, l.title ASC
")->fetchAll();

$pageTitle = 'Users — Admin 237Biz';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <h1 style="font-family:'Fraunces',serif;font-weight:900;font-size:2rem;">👤 User Management</h1>
  </div>
</div>

<section class="page-section">
  <div class="container">

    <!-- Admin Nav -->
    <div class="filter-tabs" style="margin-bottom:2rem;flex-wrap:wrap;">
      <a href="<?= SITE_URL ?>/admin/" class="filter-tab">📋 Listings</a>
      <a href="<?= SITE_URL ?>/agent-health-checks.php" class="filter-tab">🩺 Health Check</a>
      <a href="<?= SITE_URL ?>/admin/users.php" class="filter-tab active">👤 Users</a>
      <a href="<?= SITE_URL ?>/admin/orders.php" class="filter-tab">📦 Orders</a>
      <a href="<?= SITE_URL ?>/admin/leads.php" class="filter-tab">🌐 Website Leads</a>
      <a href="<?= SITE_URL ?>/admin/enquiries.php" class="filter-tab">📬 Enquiries</a>
      <a href="<?= SITE_URL ?>/admin/claims.php" class="filter-tab">🏢 Claims</a>
      <a href="<?= SITE_URL ?>/admin/reviews.php" class="filter-tab">⭐ Reviews</a>
      <a href="<?= SITE_URL ?>/admin/categories.php" class="filter-tab">📂 Categories</a>
      <a href="<?= SITE_URL ?>/admin/locations.php" class="filter-tab">📍 Locations</a>
      <a href="<?= SITE_URL ?>/admin/subscribers.php" class="filter-tab">📬 Newsletter</a>
      <a href="<?= SITE_URL ?>/admin/promos.php" class="filter-tab">🎁 Promo Codes</a>
      <a href="<?= SITE_URL ?>/admin/packages.php" class="filter-tab">💳 Packages</a>
      <a href="<?= SITE_URL ?>/admin/seo-content.php" class="filter-tab">📝 SEO Content</a>
      <a href="<?= SITE_URL ?>/dashboard" class="filter-tab">← Dashboard</a>
    </div>
    <!-- Stats -->
    <div class="dash-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:2rem;">
      <div class="dash-stat"><strong><?= $totalUsers ?></strong><span>Total Users</span></div>
      <div class="dash-stat"><strong><?= $totalAdmins ?></strong><span>Admins</span></div>
      <div class="dash-stat"><strong style="color:var(--yellow);"><?= $unverified ?></strong><span>Unverified</span></div>
      <div class="dash-stat"><strong style="color:#ff6b6b;"><?= $locked ?></strong><span>Locked</span></div>
    </div>


    <!-- ADD USER FORM -->
    <div class="listing-widget" style="margin-bottom:2rem;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;">
        <h4 style="margin-bottom:0;">+ Add New User</h4>
        <button onclick="document.getElementById('add-user-form').style.display=document.getElementById('add-user-form').style.display==='none'?'block':'none'"
                class="btn btn-primary btn-sm">+ Add User</button>
      </div>
      <div id="add-user-form" style="display:none;">
        <form method="POST">
          <input type="hidden" name="csrf" value="<?= csrf() ?>">
          <input type="hidden" name="action" value="create_user">
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;">
            <div class="form-group" style="margin-bottom:0;">
              <label>Full Name *</label>
              <input type="text" name="name" required placeholder="e.g. John Doe">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Email Address *</label>
              <input type="email" name="email" required placeholder="john@example.com">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Phone</label>
              <input type="tel" name="phone" placeholder="+237 6XX XXX XXX">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Role</label>
              <select name="role">
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Custom Password <small style="color:var(--muted-2);font-weight:300;">(leave blank to auto-generate)</small></label>
              <input type="text" name="custom_password" placeholder="Min. 8 characters" style="font-family:monospace;">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Assign to Listing <small style="color:var(--muted-2);font-weight:300;">(optional)</small></label>
              <select name="assign_listing_id">
                <option value="">— No assignment —</option>
                <?php foreach ($unownedListings as $ul): ?>
                  <option value="<?= $ul['id'] ?>">
                    <?= e($ul['title']) ?> (<?= e($ul['loc_en']) ?>)
                    <?php // Mark already-owned listings ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small style="color:var(--muted-2);font-size:0.72rem;">The user will become the owner and can edit this listing from their dashboard.</small>
            </div>
          </div>
          <div style="margin-top:1rem;display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap;">
            <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.85rem;color:var(--muted);cursor:pointer;">
              <input type="checkbox" name="send_welcome" checked style="accent-color:var(--green);">
              Send welcome email with login details
            </label>
            <button type="submit" class="btn btn-primary">Create User</button>
          </div>
          <p style="font-size:0.75rem;color:var(--muted-2);margin-top:0.75rem;">
            💡 If you don't send a welcome email, the generated password will be shown in the success message — copy it before navigating away.
          </p>
        </form>
      </div>
    </div>

    <!-- Search -->
    <form action="" method="GET" style="display:flex;gap:0.5rem;margin-bottom:1.5rem;">
      <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search by name or email..."
             style="flex:1;background:var(--card);border:1px solid var(--border);border-radius:6px;color:var(--white);font-family:'DM Sans',sans-serif;font-size:0.9rem;padding:0.7rem 1rem;outline:none;">
      <button type="submit" class="btn btn-primary">Search</button>
      <?php if ($search): ?><a href="<?= SITE_URL ?>/admin/users.php" class="btn btn-outline">Clear</a><?php endif; ?>
    </form>

    <?php foreach ($errors as $e): ?><div class="flash flash-error"><?= e($e) ?></div><?php endforeach; ?>

    <!-- Users Table -->
    <div class="listing-widget">
      <div style="overflow-x:auto;">
        <table class="data-table">
          <thead>
            <tr>
              <th>User</th>
              <th>Role</th>
              <th>Status</th>
              <th>Listings</th>
              <th>Orders</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $u): ?>
              <tr>
                <td>
                  <div style="color:var(--white);font-weight:500;font-size:0.875rem;"><?= e($u['name']) ?></div>
                  <div style="font-size:0.75rem;color:var(--muted-2);"><?= e($u['email']) ?></div>
                  <?php if ($u['phone']): ?><div style="font-size:0.72rem;color:var(--muted-2);"><?= e($u['phone']) ?></div><?php endif; ?>
                  <?php if ($u['locked_until'] && strtotime($u['locked_until']) > time()): ?>
                    <span style="font-size:0.68rem;color:#ff6b6b;">🔒 Locked until <?= date('H:i d M', strtotime($u['locked_until'])) ?></span>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge <?= $u['role']==='admin' ? 'badge-approved' : 'badge-pending' ?>">
                    <?= ucfirst($u['role']) ?>
                  </span>
                </td>
                <td>
                  <span class="badge <?= $u['verified'] ? 'badge-approved' : 'badge-rejected' ?>">
                    <?= $u['verified'] ? '✓ Verified' : '✗ Unverified' ?>
                  </span>
                  <?php if (($u['login_attempts'] ?? 0) > 0): ?>
                    <div style="font-size:0.68rem;color:var(--yellow);margin-top:0.2rem;"><?= $u['login_attempts'] ?> failed attempts</div>
                  <?php endif; ?>
                </td>
                <td style="text-align:center;color:var(--white);"><?= $u['listing_count'] ?></td>
                <td style="text-align:center;color:var(--white);"><?= $u['order_count'] ?></td>
                <td style="font-size:0.78rem;color:var(--muted-2);"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                <td>
                  <div style="display:flex;flex-direction:column;gap:0.35rem;">

                    <!-- Reset Password -->
                    <button onclick="openResetModal(<?= $u['id'] ?>, '<?= e($u['name']) ?>', '<?= e($u['email']) ?>')"
                            class="btn btn-primary btn-sm">🔑 Reset Password</button>

                    <!-- Unlock if locked -->
                    <?php if ($u['locked_until'] && strtotime($u['locked_until']) > time()): ?>
                      <form method="POST" style="display:inline;">
                        <input type="hidden" name="csrf" value="<?= csrf() ?>">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button name="action" value="unlock" class="btn btn-outline btn-sm" style="width:100%;">🔓 Unlock</button>
                      </form>
                    <?php endif; ?>

                    <!-- Toggle verified -->
                    <form method="POST" style="display:inline;">
                      <input type="hidden" name="csrf" value="<?= csrf() ?>">
                      <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                      <button name="action" value="toggle_verified" class="btn btn-outline btn-sm" style="width:100%;">
                        <?= $u['verified'] ? '✗ Unverify' : '✓ Verify' ?>
                      </button>
                    </form>

                    <!-- Toggle role (only if not current admin) -->
                    <?php if ($u['id'] != $_SESSION['user_id']): ?>
                      <form method="POST" style="display:inline;">
                        <input type="hidden" name="csrf" value="<?= csrf() ?>">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button name="action" value="toggle_role" class="btn btn-outline btn-sm" style="width:100%;">
                          <?= $u['role']==='admin' ? '↓ Remove Admin' : '↑ Make Admin' ?>
                        </button>
                      </form>

                      <!-- Assign listing -->
                      <button onclick="openAssignModal(<?= $u['id'] ?>, '<?= e(addslashes($u['name'])) ?>')"
                              class="btn btn-outline btn-sm" style="width:100%;color:var(--yellow);border-color:rgba(245,200,66,0.3);">
                        📋 Assign Listing
                      </button>

                    <!-- Delete -->
                      <form method="POST" style="display:inline;" onsubmit="return confirm('Delete <?= e($u['name']) ?>? This cannot be undone.')">
                        <input type="hidden" name="csrf" value="<?= csrf() ?>">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button name="action" value="delete" class="btn btn-sm" style="width:100%;background:rgba(230,50,50,0.1);color:#ff6b6b;border:1px solid rgba(230,50,50,0.3);">✗ Delete</button>
                      </form>
                    <?php endif; ?>

                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</section>


<!-- ASSIGN LISTING MODAL -->
<div id="assign-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:500;align-items:center;justify-content:center;">
  <div style="background:#122B1C;border:1px solid var(--border);border-radius:16px;padding:2rem;width:100%;max-width:460px;margin:1rem;">
    <h3 style="font-family:'Fraunces',serif;font-weight:700;margin-bottom:0.35rem;">📋 Assign Listing</h3>
    <p id="assign-user-info" style="font-size:0.83rem;color:var(--muted);margin-bottom:1.5rem;"></p>
    <form method="POST">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" value="assign_listing">
      <input type="hidden" name="user_id" id="assign-user-id">
      <div class="form-group">
        <label>Select Listing</label>
        <select name="listing_id" required>
          <option value="">— Choose a listing —</option>
          <?php foreach ($unownedListings as $ul): ?>
            <option value="<?= $ul['id'] ?>"><?= e($ul['title']) ?> (<?= e($ul['loc_en']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <p style="font-size:0.75rem;color:var(--muted-2);margin-bottom:1rem;">
        The user will become the owner of this listing and can edit it from their dashboard.
      </p>
      <div style="display:flex;gap:0.75rem;">
        <button type="submit" class="btn btn-primary" style="flex:1;">Assign Listing</button>
        <button type="button" onclick="document.getElementById('assign-modal').style.display='none'" class="btn btn-outline" style="flex:1;">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- RESET PASSWORD MODAL -->
<div id="reset-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:500;align-items:center;justify-content:center;">
  <div style="background:#122B1C;border:1px solid var(--border);border-radius:16px;padding:2rem;width:100%;max-width:420px;margin:1rem;">
    <h3 style="font-family:'Fraunces',serif;font-weight:700;margin-bottom:0.35rem;">🔑 Reset Password</h3>
    <p id="modal-user-info" style="font-size:0.83rem;color:var(--muted);margin-bottom:1.5rem;"></p>
    <form method="POST" id="reset-form">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="action" value="reset_password">
      <input type="hidden" name="user_id" id="modal-user-id">
      <div class="form-group">
        <label>New Password *</label>
        <input type="text" name="new_password" id="modal-new-password" required
               placeholder="Min. 8 characters"
               style="font-family:monospace;"
               value="<?= substr(str_shuffle('ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#'), 0, 12) ?>">
      </div>
      <p style="font-size:0.75rem;color:var(--muted-2);margin-bottom:1rem;">
        📧 The user will be emailed their new password automatically.
      </p>
      <div style="display:flex;gap:0.75rem;">
        <button type="submit" class="btn btn-primary" style="flex:1;">Reset Password</button>
        <button type="button" onclick="closeResetModal()" class="btn btn-outline" style="flex:1;">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAssignModal(id, name) {
  document.getElementById('assign-user-id').value = id;
  document.getElementById('assign-user-info').textContent = 'Assigning a listing to: ' + name;
  document.getElementById('assign-modal').style.display = 'flex';
}
document.getElementById('assign-modal').addEventListener('click', function(e) {
  if (e.target === this) this.style.display = 'none';
});

function openResetModal(id, name, email) {
  document.getElementById('modal-user-id').value = id;
  document.getElementById('modal-user-info').textContent = name + ' (' + email + ')';
  document.getElementById('reset-modal').style.display = 'flex';
}
function closeResetModal() {
  document.getElementById('reset-modal').style.display = 'none';
}
document.getElementById('reset-modal').addEventListener('click', function(e) {
  if (e.target === this) closeResetModal();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
